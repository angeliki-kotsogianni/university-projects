public interface CityInterface {
    public int getID();

    public void setID(int id);

    public String getName();

    public void setName(String name);

    public int getPopulation();

    public void setPopulation(int population);

    public int getInfluenzaCases();

    public void setInfluenzaCases(int influenzaCases);
}
